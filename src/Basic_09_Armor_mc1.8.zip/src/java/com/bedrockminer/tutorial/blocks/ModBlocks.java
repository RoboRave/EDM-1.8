package com.bedrockminer.tutorial.blocks;

public final class ModBlocks {

	public static void createBlocks() {
	}

}
