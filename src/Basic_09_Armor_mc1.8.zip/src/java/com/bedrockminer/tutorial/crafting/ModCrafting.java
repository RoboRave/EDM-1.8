package com.bedrockminer.tutorial.crafting;

public final class ModCrafting {

	public static void initCrafting() {
	}
}
