package com.bedrockminer.tutorial.blocks;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraftforge.fml.common.registry.GameRegistry;

import com.bedrockminer.tutorial.items.ModItems;


public final class ModBlocks {

	public static Block tutorial_ore;
	public static Block tutorial_multi_ore;

	public static final void createBlocks() {
		GameRegistry.registerBlock(tutorial_ore = new ModBlockOre("tutorial_ore", Material.rock, ModItems.tutorialItem, 2, 4), "tutorial_ore");
		GameRegistry.registerBlock(tutorial_multi_ore = new ModBlockMultiOre("tutorial_multi_ore", Material.rock), "tutorial_multi_ore");
	}
}
