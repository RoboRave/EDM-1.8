package com.bedrockminer.tutorial;

import com.bedrockminer.tutorial.blocks.ModBlocks;
import com.bedrockminer.tutorial.items.ModItems;
import com.bedrockminer.tutorial.world.TutorialWorldGenerator;

import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class CommonProxy {

	public void preInit(FMLPreInitializationEvent e) {
		ModItems.createItems();
		ModBlocks.createBlocks();
	}

	public void init(FMLInitializationEvent e) {
		GameRegistry.registerWorldGenerator(new TutorialWorldGenerator(), 0);
	}

	public void postInit(FMLPostInitializationEvent e) {

	}
}
